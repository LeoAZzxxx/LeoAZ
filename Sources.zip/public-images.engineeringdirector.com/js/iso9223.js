// HELPER FOR OSM MAP
// legend control unit
class LegendControl extends ol.control.Control {

  constructor(opt_options) {
    var options = opt_options || {}

    let controlDiv = document.createElement('div')
    controlDiv.innerHTML = 'Legend'
    controlDiv.className = 'ol-unselectable ol-control legend-control'
    controlDiv.style.right = '10px'
    controlDiv.style.top = '10px'
    controlDiv.style.backgroundColor = 'rgb(255, 255, 255)'
    controlDiv.style.fontFamily = 'Arial'
    controlDiv.style.fontSize = '16px'
    controlDiv.style.padding = '5px'
    controlDiv.style.color = '#666'
    controlDiv.width = '44px'

    // box for each of the classes
    // that lines up with each color
    let cbox = document.createElement('div')
    cbox.innerHTML = 'C1.0'
    cbox.style.backgroundColor = 'rgb(56,168,0)'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.padding = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C1.5'
    cbox.style.backgroundColor = 'rgb(87,186,0)'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.padding = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C2.0'
    cbox.style.backgroundColor = 'rgb(122,203,0)'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.padding = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C2.5'
    cbox.style.backgroundColor = 'rgb(162,220,0)'
    cbox.style.padding = '2px'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C3.0'
    cbox.style.backgroundColor = 'rgb(206,238,0)'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.padding = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C3.5'
    cbox.style.backgroundColor = 'rgb(255,255,0)'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.padding = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C4.0'
    cbox.style.backgroundColor = 'rgb(255,204,0)'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.padding = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C4.5'
    cbox.style.color = 'rgb(255,153,0)'
    cbox.style.backgroundColor = 'rgb(253, 200, 32)'
    cbox.style.padding = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C5'
    cbox.style.backgroundColor = 'rgb(255,102,0)'
    cbox.style.padding = '2px'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'C5.5'
    cbox.style.backgroundColor = 'rgb(255,51,0)'
    cbox.style.padding = '2px'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)

    cbox = document.createElement('div')
    cbox.innerHTML = 'CX'
    cbox.style.backgroundColor = 'rgb(255,0,0)'
    cbox.style.padding = '2px'
    cbox.style.color = 'rgb(255, 255, 255)'
    cbox.style.borderRadius = '2px'
    cbox.style.textAlign = 'center'
    controlDiv.append(cbox)


    super({
      element: controlDiv,
      target: options.target,
    })

  }
}

// note: init map probably also needs to wait for document
// to be ready, so call the function and then wait and then
// load the map or else it won't load properly for everyone
function initMap() {
  $(document).ready(function() {
    let isomap = $(".iso9223Map")
    if (isomap) {

      let topPart = document.createElement("div");
      topPart.style.width = "100%"
      topPart.style.display = "flex"
      topPart.style.flexDirection = "row"
      topPart.setAttribute("id", "topPart")

      let searchPart = document.createElement("div")
      searchPart.style.width = "100%"
      searchPart.style.padding = "8px";
      searchPart.setAttribute("id", "searchPart")

      let typeAhead = document.createElement("input");
      typeAhead.type = "text"
      typeAhead.setAttribute("id", "searchTextField")
      typeAhead.setAttribute("autocomplete", "off")
      typeAhead.setAttribute("placeholder", "Type in Address")
      typeAhead.setAttribute("size", "50")
      searchPart.append(typeAhead)

      let sep = document.createElement("div")
      sep.style.display = 'block'
      sep.style.height = '30px'
      sep.innerHTML = 'OR'
      sep.style.fontWeight = '700'
      sep.style.textAlign = 'center'
      sep.style.verticalAlign = 'middle'
      searchPart.append(sep)

      // add spots to end latitude and longitude
      let latInput  = document.createElement("input")
      latInput.type = "text"
      latInput.setAttribute("id", "latitude")
      latInput.setAttribute("placeholder", "Latitude")
      searchPart.append(latInput)

      let lonInput  = document.createElement("input")
      lonInput.type = "text"
      lonInput.setAttribute("id", "longitude")
      lonInput.setAttribute("placeholder", "Longitude")
      searchPart.append(lonInput)

      // button to manually search
      let btnInput = document.createElement("button")
      btnInput.setAttribute("id", "manualSearch")
      btnInput.setAttribute("placeholder", "Longitude")
      // zoho button styles
      btnInput.className = 'zpbutton zpbutton-type-primary'
      btnInput.style.paddingTop = '10px'
      btnInput.style.paddingBottom = '10px'
      btnInput.style.paddingLeft = '20px'
      btnInput.style.paddingRight = '20px'
      btnInput.style.marginTop = '10px'
      btnInput.style.marginBottom = '12px'
      btnInput.innerText = "Search"
      btnInput.addEventListener("click", function() {
        setCoordsManually()
      })
      searchPart.append(btnInput)

      topPart.append(searchPart)

      let infoPart = document.createElement("div")
      infoPart.setAttribute("id", "infoPart")
      infoPart.style.padding = "8px"
      infoPart.style.width = "0%"
      topPart.append(infoPart)

      isomap.append(topPart)

      let corem = document.createElement("div")
      corem.setAttribute("id", "coreMap")
      corem.style.height = "80vh"
      corem.style.width = "100%"
      corem.style.marginTop = "10px"
      isomap.append(corem)

      // add an openlayers map view
      var bingLayer = new ol.layer.Tile({
        source: new ol.source.BingMaps({
        name: 'basemap',
        key: 'AkJXHF_4pQ_rTQ_VV6W-ojLskDku0Cfvxk_VdA8kNOmbkteIs6W-DvAs48C2dF2X',
        maxZoom: 19,
        imagerySet: 'CanvasLight'})
      })

      //let tileUrl = 'https://tile.atmosphericiq.com/1.0.0/384b6ab0-8235-43d8-aa59-35bc7b610ce9/2/TMS/{z}/{x}/{-y}.png'
      let tileUrl = 'https://tile.atmosphericiq.com/1.0.0/7e61a177-81cc-4d6a-b8ba-dd643917a4fe/5/TMS/{z}/{x}/{-y}.png'
      let isoLayer = new ol.layer.Tile({
        name: 'iso9223',
        preload: Infinity,
        source: new ol.source.XYZ({
          url: tileUrl
        })
      })
      isoLayer.setOpacity(0.6)

      // make one layer for each C class
      let layerList = [bingLayer, isoLayer]
      let pointLayer = new ol.layer.Vector({
        name: 'point',  
        source: new ol.source.Vector({}),
        style: pointStyleFunction
      })
      layerList.push(pointLayer)

      centerPt = ol.proj.fromLonLat([0, 0])
      window.iso_map = new ol.Map({
        target: 'coreMap',
        layers: layerList,
        overlays: [],
        controls: ol.control.defaults.defaults().extend([
          new LegendControl()
        ]),
        view: new ol.View({
          center: centerPt,
          zoom: 2
        })
      })

    }

    // configure google 
    const input = document.getElementById("searchTextField")
    const options = {
      fields: ["address_components", "geometry", "formatted_address"],
      strictBounds: false,
      types: ["address"],
    }
    const autocomplete = new google.maps.places.Autocomplete(input, options)
    autocomplete.addListener('place_changed', () => {
      let place = autocomplete.getPlace()
      let lat = place.geometry.location.lat()
      let lon = place.geometry.location.lng()
      $("#latitude").val(lat.toString())
      $("#longitude").val(lon.toString())
      setCoords(lat, lon, place['formatted_address'],'EDI_GOOGLE_PLACES')
    })
})
}

// get result
function setCoordsManually() {
  let lat = $("#latitude").val()
  let lon = $("#longitude").val()
  let reproj = ol.proj.fromLonLat([lon, lat])
  setCoords(lat, lon, null, 'EDI_MANUAL')
  logSearch('MANUAL', [lon, lat])
}


// sets the coordinates in the html text boxes
function setCoords(lat, lon, address=null, origin=null) {
  // need to reproject to 3857
  let reproj = ol.proj.fromLonLat([lon, lat])
  feature = new ol.Feature({
    name: 'test',
    geometry: new ol.geom.Point(reproj)
  })
  let isoUri = 'https://secure.engineeringdirector.com/partner/iso9223/query?substrate=fe&latitude='+lat+'&longitude='+lon
  if (address) {
    isoUri += '&address='+address
  }
  if (origin) {
    isoUri += '&origin='+origin
  }
  
  $.ajax({
    url: isoUri,
    headers: {"Authorization": "Bearer 60a34604-441a-11ed-996a-ff70344b693b"},
    success: function(r) {
      let score = r.corrosion.Fe.classification
      if (score) {
        layerName = score.replace('C', '').replace('.0', '')
        if (layerName == '6') {
          layerName = 'X'
        }
        layerName = 'C' + layerName
        feature.set('name', layerName)
        let pl = getLayerByName('point') 
        pl.getSource().addFeature(feature)
        logSearch('GOOGLE_PLACES', [lon, lat], address, score)

        // provide room to show data
        $("#searchPart").css("width", "50%")
        $("#infoPart").css("border", "0")
        $("#infoPart").css("width", "50%")
        $("#infoPart").css("height", "100%")

        // show stuff in info part
        let results = document.createElement('div')

        let h4 = document.createElement('h4')
        h4.innerHTML = "ISO9223 Results"
        results.append(h4)

        let t = document.createElement('table')
        t.setAttribute('border', '0')
        t.style.padding = '2px'
        t.style.fontFamily = 'monospace'
        t.style.border = '0'
        let tr1 = document.createElement('tr')
        let td1 = document.createElement('td')
        td1.innerHTML = 'ISO9223 Steel Corrosion Class'
        let td2 = document.createElement('td')
        td2.innerHTML = layerName
        tr1.appendChild(td1)
        tr1.appendChild(td2)
        t.appendChild(tr1)

        let tr3 = document.createElement('tr')
        let td3 = document.createElement('td')
        td3.innerHTML = 'Steel Corrosion Rate'
        td3.style.borderBottom = '1px solid black'
        let td4 = document.createElement('td')
        td4.innerHTML = r.corrosion.Fe.um_year + ' µm/year'
        td4.style.borderBottom = '1px solid black'
        tr3.appendChild(td3)
        tr3.appendChild(td4)
        t.appendChild(tr3)

        // now add Zinc iso9223 class
        //let tr18 = document.createElement('tr')
        //let td18 = document.createElement('td')
        //td18.innerHTML = 'Zinc ISO9223 Class'
        //let td21 = document.createElement('td')
        //td21.innerHTML = r.corrosion.Zn.classification
        //tr18.appendChild(td18)
        //tr18.appendChild(td21)
        //t.appendChild(tr18)

        // now add another two lines for Zinc ISO9223 and zinc rate
        //let tr19 = document.createElement('tr')
        //let td19 = document.createElement('td')
        //td19.innerHTML = 'Zinc Corrosion Rate'
        //td19.style.borderBottom = '1px solid black'
        //let td20 = document.createElement('td')
        //td20.innerHTML = r.corrosion.Zn.um_year + ' µm/year'
        //td20.style.borderBottom = '1px solid black'
        //tr19.appendChild(td19)
        //tr19.appendChild(td20)
        //t.appendChild(tr19)

        let tr4 = document.createElement('tr')
        let td5 = document.createElement('td')
        td5.innerHTML = 'Mean Average Temperature'
        let td6 = document.createElement('td')
        td6.innerHTML = r.inputs.mean_temp_c + ' C'
        tr4.appendChild(td5)
        tr4.appendChild(td6)
        t.appendChild(tr4)

        let tr5 = document.createElement('tr')
        let td7 = document.createElement('td')
        td7.innerHTML = 'Mean Average Relative Humidity'
        let td8 = document.createElement('td')
        td8.innerHTML = r.inputs.mean_rh + ' %'
        tr5.appendChild(td7)
        tr5.appendChild(td8)
        t.appendChild(tr5)

        let tr6 = document.createElement('tr')
        let td9 = document.createElement('td')
        td9.innerHTML = 'Mean SO2 Deposition'
        let td10 = document.createElement('td')
        td10.innerHTML = r.inputs.so2_mgm2d + ' mg/m²d'
        tr6.appendChild(td9)
        tr6.appendChild(td10)
        t.appendChild(tr6)

        let tr7 = document.createElement('tr')
        let td11 = document.createElement('td')
        td11.innerHTML = 'Mean Cl Deposition'
        let td12 = document.createElement('td')
        td12.innerHTML = r.inputs.cl_mgm2d + ' mg/m²d'
        tr7.appendChild(td11)
        tr7.appendChild(td12)
        t.appendChild(tr7)
        
        let tr8 = document.createElement('tr')
        let td13 = document.createElement('td')
        td13.innerHTML = 'Mean Wind Speed'
        let td14 = document.createElement('td')
        td14.innerHTML = r.inputs.wind_speed_ms + ' m/s'
        tr8.appendChild(td13)
        tr8.appendChild(td14)
        t.appendChild(tr8)

        results.append(t)
        $('#infoPart').empty()
        $('#infoPart').append(results)

      }
    }
  })
  zoomToCoords(reproj)
}

// return a layer by its name
// not that forEach function doesn't return
// anything and you have to set using this weird way
function getLayerByName(name) {
  let layerList = window.iso_map.getLayers()
  let match = null
  layerList.forEach(function(lyr) {
    if (lyr.get('name') === name) {
      console.log('layer found' + name)
      match = lyr
    }
  })
  return match
}

// updates the map search
// note coords are in (x,y) format
function logSearch(origin, coords, address=null, score=null) {
  let payload = {'origin': origin,
    'latitude': coords[1],
    'longitude': coords[0],
    'formatted_address': address,
    'score': score}
  // 7/10/23 - disabled this and we log during iso9223 search now
  //let uri = 'https://secure.engineeringdirector.com/iso9223/log'
  //$.post(uri, payload)
}

// zoom smoothly to a set of coordinates
function zoomToCoords(pt) {
  window.iso_map.getView().animate({
    center: pt, zoom: 7,
    duration: 500})
}

function pointStyleFunction(feature, resolution) {
  s = new ol.style.Style ({
    text: new ol.style.Text({
      font: '20px Calibri,sans-serif',
      overflow: true,
      fill: new ol.style.Fill({
        color: '#000'
      }),
      stroke: new ol.style.Stroke({
        color: '#fff',
        width: 3
      }),
      offsetY: 0
    }),
    image: new ol.style.Circle({
      radius: 20,
      fill: new ol.style.Fill({color: 'rgb(255, 255, 255)'}),
      stroke: new ol.style.Stroke({color: 'black', width: 1}),
    })
  })
  s.getText().setText(feature.get('name'));
  return s
}
